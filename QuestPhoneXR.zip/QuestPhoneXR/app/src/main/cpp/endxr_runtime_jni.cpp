#include <jni.h>

#include <cstdint>
#include <string>

#include "endxr_runtime_core.hpp"
#include "endxr_openxr_android_self_test.hpp"
#include "endxr_openxr_runtime.hpp"
#include <algorithm>

namespace {

endxr::RuntimeCore g_runtime_core;

jstring makeError(JNIEnv* env, const std::string& error) {
    if (error.empty()) {
        return nullptr;
    }
    return env->NewStringUTF(error.c_str());
}

} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeInitialize(
    JNIEnv* env,
    jobject,
    jint width,
    jint height,
    jint target_fps
) {
    const endxr::RuntimeConfig config{
        static_cast<std::uint32_t>(width),
        static_cast<std::uint32_t>(height),
        static_cast<std::uint32_t>(target_fps)
    };
    std::string error;
    g_runtime_core.initialize(config, &error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeCreateSession(
    JNIEnv* env,
    jobject
) {
    std::string error;
    g_runtime_core.createSession(&error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeBeginSession(
    JNIEnv* env,
    jobject
) {
    std::string error;
    g_runtime_core.beginSession(&error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jlongArray JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeWaitFrame(
    JNIEnv* env,
    jobject,
    jlong monotonic_now_ns
) {
    endxr::FrameTiming timing;
    std::string error;
    if (!g_runtime_core.waitFrame(
            static_cast<std::int64_t>(monotonic_now_ns),
            &timing,
            &error)) {
        return nullptr;
    }

    const jlong values[] = {
        static_cast<jlong>(timing.frame_index),
        static_cast<jlong>(timing.predicted_display_time_ns),
        static_cast<jlong>(timing.predicted_display_period_ns),
        static_cast<jlong>(timing.frame_deadline_ns)
    };
    jlongArray result = env->NewLongArray(4);
    if (result == nullptr) {
        std::string cleanup_error;
        g_runtime_core.endFrame(timing, false, &cleanup_error);
        return nullptr;
    }
    env->SetLongArrayRegion(result, 0, 4, values);
    if (env->ExceptionCheck()) {
        std::string cleanup_error;
        g_runtime_core.endFrame(timing, false, &cleanup_error);
        return nullptr;
    }
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeEndFrame(
    JNIEnv* env,
    jobject,
    jlong frame_index,
    jlong predicted_display_time_ns,
    jlong predicted_display_period_ns,
    jlong frame_deadline_ns,
    jboolean rendered_successfully
) {
    const endxr::FrameTiming timing{
        static_cast<std::uint64_t>(frame_index),
        static_cast<std::int64_t>(predicted_display_time_ns),
        static_cast<std::int64_t>(predicted_display_period_ns),
        static_cast<std::int64_t>(frame_deadline_ns)
    };
    std::string error;
    g_runtime_core.endFrame(timing, rendered_successfully == JNI_TRUE, &error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeRequestStop(
    JNIEnv* env,
    jobject
) {
    std::string error;
    g_runtime_core.requestStop(&error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeDestroySession(
    JNIEnv* env,
    jobject
) {
    std::string error;
    g_runtime_core.destroySession(&error);
    return makeError(env, error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeMarkLost(
    JNIEnv* env,
    jobject,
    jstring reason
) {
    std::string message;
    if (reason != nullptr) {
        const char* chars = env->GetStringUTFChars(reason, nullptr);
        if (chars != nullptr) {
            message.assign(chars);
            env->ReleaseStringUTFChars(reason, chars);
        }
    }

    std::string error;
    g_runtime_core.markLost(message, &error);
    return makeError(env, error);
}

extern "C" JNIEXPORT void JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeShutdown(
    JNIEnv*,
    jobject
) {
    g_runtime_core.shutdown();
}

extern "C" JNIEXPORT jlongArray JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeSnapshot(
    JNIEnv* env,
    jobject
) {
    const auto snapshot = g_runtime_core.snapshot();
    const jlong values[] = {
        static_cast<jlong>(snapshot.state),
        static_cast<jlong>(snapshot.config.width),
        static_cast<jlong>(snapshot.config.height),
        static_cast<jlong>(snapshot.config.target_fps),
        static_cast<jlong>(snapshot.frames_started),
        static_cast<jlong>(snapshot.submitted_frames),
        static_cast<jlong>(snapshot.dropped_frames),
        static_cast<jlong>(snapshot.late_frames),
        static_cast<jlong>(snapshot.last_lateness_ns)
    };

    jlongArray result = env->NewLongArray(9);
    if (result == nullptr) {
        return nullptr;
    }
    env->SetLongArrayRegion(result, 0, 9, values);
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeLastError(
    JNIEnv* env,
    jobject
) {
    return makeError(env, g_runtime_core.snapshot().last_error);
}


extern "C" void endxrSetHeadOrientation(float x, float y, float z, float w);

extern "C" JNIEXPORT void JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeSetHeadOrientation(
    JNIEnv*, jobject, jfloat x, jfloat y, jfloat z, jfloat w
) {
    endxrSetHeadOrientation(x, y, z, w);
}


extern "C" JNIEXPORT void JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeSetControllerInput(
    JNIEnv* env, jobject, jfloatArray left, jfloatArray right
) {
    if (left == nullptr || right == nullptr ||
        env->GetArrayLength(left) < 6 || env->GetArrayLength(right) < 6) {
        endxrClearControllerInput();
        return;
    }
    jfloat l[6]{}, r[6]{};
    env->GetFloatArrayRegion(left, 0, 6, l);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return; }
    env->GetFloatArrayRegion(right, 0, 6, r);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return; }
    auto publish = [](std::uint32_t hand, const jfloat* v) {
        const auto buttons = static_cast<std::uint32_t>(std::max(0.0f, v[5]));
        endxrSetControllerInput(hand, v[0] >= 0.5f ? 1u : 0u,
            v[1], v[2], v[3], v[4], buttons);
    };
    publish(0, l);
    publish(1, r);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_noyclic_questphonexr_runtime_EndXrRuntimeBridge_nativeRunOpenXrSelfTest(
    JNIEnv* env,
    jobject,
    jobject activity
) {
    if (activity == nullptr) {
        return env->NewStringUTF("OpenXR probe: FAIL · Activity is null");
    }

    JavaVM* vm = nullptr;
    if (env->GetJavaVM(&vm) != JNI_OK || vm == nullptr) {
        return env->NewStringUTF("OpenXR probe: FAIL · JavaVM unavailable");
    }

    jobject activityReference = env->NewGlobalRef(activity);
    if (activityReference == nullptr) {
        return env->NewStringUTF("OpenXR probe: FAIL · Activity reference allocation failed");
    }

    const std::string result = runEndXrOpenXrAndroidSelfTest(vm, activityReference);
    env->DeleteGlobalRef(activityReference);
    return env->NewStringUTF(result.c_str());
}
