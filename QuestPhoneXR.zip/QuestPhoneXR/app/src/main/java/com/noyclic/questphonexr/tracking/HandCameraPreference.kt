package com.noyclic.questphonexr.tracking

import android.content.Context

/**
 * Which phone camera feeds hand tracking. In a VR viewer the screen faces the user, so
 * the rear camera is the one that sees the hands: it is the default.
 */
class HandCameraPreferenceStore(context: Context) {
    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun useFrontCamera(): Boolean = preferences.getBoolean(KEY_USE_FRONT, false)

    fun setUseFrontCamera(value: Boolean) {
        preferences.edit().putBoolean(KEY_USE_FRONT, value).apply()
    }

    companion object {
        private const val PREFERENCES_NAME = "hand_camera"
        private const val KEY_USE_FRONT = "use_front_camera"

        /** The preferred lens when it exists; otherwise whichever lens the phone has. */
        fun resolveUseFront(preferFront: Boolean, hasFront: Boolean, hasBack: Boolean): Boolean =
            (preferFront && hasFront) || !hasBack
    }
}
