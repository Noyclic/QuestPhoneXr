package com.noyclic.questphonexr.sandbox

import com.noyclic.questphonexr.tracking.HandTrackingMetricsSnapshot

internal enum class DiagnosisLevel(val marker: String) {
    OK("✅"), INFO("ℹ️"), WARN("⚠️"), FAIL("❌")
}

internal data class DiagnosisFinding(
    val level: DiagnosisLevel,
    val title: String,
    val hint: String = ""
)

internal enum class HandTrackingOwner(val label: String) {
    SERVICE("фоновая служба"), SANDBOX("Sandbox"), NONE("никто")
}

/** Everything the diagnosis needs, gathered by the Activity. Pure data: no Android types. */
internal data class HandDiagnosisInput(
    val cameraPermissionGranted: Boolean,
    /** Size of hand_landmarker.task in the APK, or -1 when it cannot be opened. */
    val modelAssetBytes: Long,
    val hasAnyCamera: Boolean,
    val hasFrontCamera: Boolean,
    val owner: HandTrackingOwner,
    val windowMs: Long,
    val before: HandTrackingMetricsSnapshot?,
    val after: HandTrackingMetricsSnapshot?,
    val maxHandsSeen: Int,
    val lastPipelineLatencyMs: Long,
    val inferenceIntervalMs: Long,
    val lastError: String = ""
)

internal data class HandDiagnosisReport(
    val findings: List<DiagnosisFinding>,
    val verdict: String
) {
    fun render(): String = buildString {
        append("ИТОГ: ").append(verdict).append("\n\n")
        findings.forEach { finding ->
            append(finding.level.marker).append(' ').append(finding.title).append('\n')
            if (finding.hint.isNotBlank()) append("    → ").append(finding.hint).append('\n')
        }
    }
}

internal object HandTrackingDiagnostician {
    private const val MIN_MODEL_BYTES = 1_000_000L
    private const val SLOW_RESULT_FPS = 8f
    private const val HIGH_LATENCY_MS = 150L
    private const val ECONOMY_INTERVAL_MS = 100L
    private const val BLACK_FRAME_LUMA = 8f
    private const val FLAT_FRAME_STDDEV = 4f
    private const val DARK_FRAME_LUMA = 40f

    fun diagnose(input: HandDiagnosisInput): HandDiagnosisReport {
        val f = mutableListOf<DiagnosisFinding>()

        // 1. Preconditions: nothing below can work without these.
        if (input.cameraPermissionGranted) {
            f += DiagnosisFinding(DiagnosisLevel.OK, "Разрешение на камеру выдано")
        } else {
            f += DiagnosisFinding(
                DiagnosisLevel.FAIL, "Нет разрешения на камеру",
                "Настройки → Приложения → QuestPhoneXR → Разрешения → Камера → Разрешить."
            )
        }
        f += when {
            input.modelAssetBytes >= MIN_MODEL_BYTES -> DiagnosisFinding(
                DiagnosisLevel.OK, "Модель hand_landmarker.task на месте (${input.modelAssetBytes / 1024} КБ)"
            )
            input.modelAssetBytes < 0 -> DiagnosisFinding(
                DiagnosisLevel.FAIL, "Модели hand_landmarker.task нет в APK",
                "Она качается только при сборке. Собери проект с интернетом (задача downloadHandLandmarkerModel)."
            )
            else -> DiagnosisFinding(
                DiagnosisLevel.FAIL, "Файл модели повреждён или обрезан (${input.modelAssetBytes} Б)",
                "Удали app/src/main/assets/hand_landmarker.task и пересобери с интернетом."
            )
        }
        f += when {
            !input.hasAnyCamera -> DiagnosisFinding(DiagnosisLevel.FAIL, "Android не сообщает ни одной камеры")
            !input.hasFrontCamera -> DiagnosisFinding(
                DiagnosisLevel.WARN, "Фронтальной камеры нет, используется задняя",
                "Держи руки перед задней камерой."
            )
            else -> DiagnosisFinding(DiagnosisLevel.OK, "Фронтальная камера есть")
        }
        f += DiagnosisFinding(DiagnosisLevel.INFO, "Камерой владеет: ${input.owner.label}")

        if (input.lastError.isNotBlank()) {
            f += DiagnosisFinding(DiagnosisLevel.FAIL, "Ошибка трекера: ${input.lastError}")
        }

        val before = input.before
        val after = input.after
        if (input.owner == HandTrackingOwner.NONE || before == null || after == null) {
            if (input.cameraPermissionGranted && input.lastError.isBlank()) {
                f += DiagnosisFinding(
                    DiagnosisLevel.FAIL, "Трекер рук не запущен",
                    "Камера не стартовала: закрой другие приложения с камерой и открой Sandbox заново."
                )
            }
            return finish(f)
        }

        // 2. Live measurement over the sampling window.
        val seconds = (input.windowMs / 1000f).coerceAtLeast(0.1f)
        val received = after.receivedFrames - before.receivedFrames
        val submitted = after.submittedFrames - before.submittedFrames
        val completed = after.completedFrames - before.completedFrames
        val droppedBusy = after.droppedBusyFrames - before.droppedBusyFrames

        if (received <= 0L) {
            f += DiagnosisFinding(
                DiagnosisLevel.FAIL, "Камера не отдаёт кадры (0 за ${"%.1f".format(seconds)} с)",
                "Камеру мог занять другой процесс или система (режим приватности Xiaomi). " +
                    "Выключи фоновую камеру, перезапусти приложение."
            )
            return finish(f)
        }
        f += DiagnosisFinding(
            DiagnosisLevel.OK, "Камера отдаёт кадры: ${"%.0f".format(received / seconds)} кадр/с " +
                "(${after.lastFrameWidthPx}×${after.lastFrameHeightPx}, поворот ${after.lastFrameRotationDegrees}°)"
        )

        val luma = after.lastFrameLumaMean
        val stddev = after.lastFrameLumaStdDev
        f += when {
            luma < BLACK_FRAME_LUMA -> DiagnosisFinding(
                DiagnosisLevel.FAIL, "Кадр чёрный (яркость ${"%.0f".format(luma)})",
                "Объектив закрыт очками/пальцем или камеру блокирует система."
            )
            stddev < FLAT_FRAME_STDDEV -> DiagnosisFinding(
                DiagnosisLevel.WARN, "Кадр почти однотонный (контраст ${"%.1f".format(stddev)})",
                "Камера смотрит в стену/внутрь VR-держателя или картинка заморожена."
            )
            luma < DARK_FRAME_LUMA -> DiagnosisFinding(
                DiagnosisLevel.WARN, "Слишком темно (яркость ${"%.0f".format(luma)})",
                "Добавь света: в темноте модель теряет руки."
            )
            else -> DiagnosisFinding(
                DiagnosisLevel.OK, "Картинка нормальная (яркость ${"%.0f".format(luma)}, контраст ${"%.0f".format(stddev)})"
            )
        }

        if (submitted > 0L && completed == 0L) {
            f += DiagnosisFinding(
                DiagnosisLevel.FAIL, "MediaPipe принимает кадры, но не возвращает результат",
                "Модель зависла. Смени «Профиль MediaPipe» или перезапусти приложение."
            )
        } else if (submitted == 0L) {
            f += DiagnosisFinding(
                DiagnosisLevel.WARN, "Ни один кадр не ушёл в модель",
                "Интервал инференса ${input.inferenceIntervalMs} мс слишком большой или трекер занят."
            )
        } else {
            val resultFps = completed / seconds
            f += if (resultFps < SLOW_RESULT_FPS) {
                DiagnosisFinding(
                    DiagnosisLevel.WARN, "MediaPipe медленный: ${"%.1f".format(resultFps)} кадр/с",
                    "Руки будут отставать. Выбери быстрый профиль и разрешение камеры 320×240."
                )
            } else {
                DiagnosisFinding(DiagnosisLevel.OK, "MediaPipe работает: ${"%.1f".format(resultFps)} кадр/с")
            }
            if (droppedBusy > submitted) {
                f += DiagnosisFinding(
                    DiagnosisLevel.INFO, "Много кадров пропущено из-за занятой модели ($droppedBusy)"
                )
            }
        }

        if (input.inferenceIntervalMs >= ECONOMY_INTERVAL_MS) {
            f += DiagnosisFinding(
                DiagnosisLevel.WARN,
                "Автоэкономия ограничивает трекинг (пауза ${input.inferenceIntervalMs} мс между кадрами)",
                "Она включается, когда телефон не тянет. Выбери профиль «Экономичный/Быстрый» вручную."
            )
        }
        if (input.lastPipelineLatencyMs > HIGH_LATENCY_MS) {
            f += DiagnosisFinding(
                DiagnosisLevel.WARN, "Большая задержка: ${input.lastPipelineLatencyMs} мс от камеры до результата"
            )
        }

        if (completed > 0L) {
            f += if (input.maxHandsSeen > 0) {
                DiagnosisFinding(DiagnosisLevel.OK, "Руки найдены (максимум ${input.maxHandsSeen} за проверку)")
            } else {
                DiagnosisFinding(
                    DiagnosisLevel.WARN, "Модель работает, но рук не нашла",
                    "Покажи ладонь целиком на 30–50 см от фронтальной камеры при хорошем свете. " +
                        "Если телефон в VR-держателе, фронталка рук не видит."
                )
            }
        }
        return finish(f)
    }

    private fun finish(findings: List<DiagnosisFinding>): HandDiagnosisReport {
        val verdict = findings.firstOrNull { it.level == DiagnosisLevel.FAIL }?.title
            ?: findings.firstOrNull { it.level == DiagnosisLevel.WARN }?.title
            ?: "всё работает"
        return HandDiagnosisReport(findings, verdict)
    }
}
