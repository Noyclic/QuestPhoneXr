package com.noyclic.questphonexr.tracking

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HandCameraPreferenceTest {
    @Test fun rearIsUsedByDefaultWhenAvailable() {
        assertFalse(HandCameraPreferenceStore.resolveUseFront(false, hasFront = true, hasBack = true))
    }

    @Test fun frontIsUsedOnlyWhenRequestedAndPresent() {
        assertTrue(HandCameraPreferenceStore.resolveUseFront(true, hasFront = true, hasBack = true))
        assertFalse(HandCameraPreferenceStore.resolveUseFront(true, hasFront = false, hasBack = true))
    }

    @Test fun fallsBackToFrontWhenThereIsNoRearCamera() {
        assertTrue(HandCameraPreferenceStore.resolveUseFront(false, hasFront = true, hasBack = false))
    }
}
