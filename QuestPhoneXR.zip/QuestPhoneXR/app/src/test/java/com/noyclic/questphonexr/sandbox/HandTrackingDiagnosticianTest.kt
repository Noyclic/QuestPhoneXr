package com.noyclic.questphonexr.sandbox

import com.noyclic.questphonexr.tracking.HandTrackingMetricsSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HandTrackingDiagnosticianTest {
    private fun metrics(
        received: Long, submitted: Long, completed: Long, busy: Long = 0L,
        luma: Float = 120f, stddev: Float = 40f
    ) = HandTrackingMetricsSnapshot(
        receivedFrames = received, submittedFrames = submitted, completedFrames = completed,
        droppedBusyFrames = busy, droppedIntervalFrames = 0L,
        lastPreprocessingMs = 3L, averagePreprocessingMs = 3f,
        lastFrameWidthPx = 640, lastFrameHeightPx = 480,
        lastFrameLumaMean = luma, lastFrameLumaStdDev = stddev
    )

    private fun input(
        permission: Boolean = true,
        model: Long = 8_000_000L,
        owner: HandTrackingOwner = HandTrackingOwner.SANDBOX,
        before: HandTrackingMetricsSnapshot? = metrics(0, 0, 0),
        after: HandTrackingMetricsSnapshot? = metrics(120, 40, 40),
        hands: Int = 1,
        interval: Long = 0L
    ) = HandDiagnosisInput(
        cameraPermissionGranted = permission, modelAssetBytes = model,
        hasAnyCamera = true, hasFrontCamera = true, owner = owner, windowMs = 4_000L,
        before = before, after = after, maxHandsSeen = hands,
        lastPipelineLatencyMs = 40L, inferenceIntervalMs = interval
    )

    @Test fun healthyPipelineReportsAllGood() {
        assertEquals("всё работает", HandTrackingDiagnostician.diagnose(input()).verdict)
    }

    @Test fun missingPermissionIsTheVerdict() {
        val report = HandTrackingDiagnostician.diagnose(input(permission = false, owner = HandTrackingOwner.NONE, before = null, after = null))
        assertEquals("Нет разрешения на камеру", report.verdict)
    }

    @Test fun missingModelIsReported() {
        val report = HandTrackingDiagnostician.diagnose(input(model = -1L))
        assertTrue(report.verdict.contains("hand_landmarker.task"))
    }

    @Test fun noCameraFramesIsFail() {
        val report = HandTrackingDiagnostician.diagnose(input(after = metrics(0, 0, 0)))
        assertTrue(report.verdict.startsWith("Камера не отдаёт кадры"))
    }

    @Test fun stuckModelIsDetected() {
        val report = HandTrackingDiagnostician.diagnose(input(after = metrics(120, 40, 0, busy = 80)))
        assertTrue(report.verdict.contains("не возвращает результат"))
    }

    @Test fun blackFrameIsFail() {
        val report = HandTrackingDiagnostician.diagnose(input(after = metrics(120, 40, 40, luma = 2f, stddev = 0f)))
        assertTrue(report.verdict.startsWith("Кадр чёрный"))
    }

    @Test fun workingModelWithoutHandsWarns() {
        val report = HandTrackingDiagnostician.diagnose(input(hands = 0))
        assertEquals("Модель работает, но рук не нашла", report.verdict)
    }

    @Test fun economyIntervalWarns() {
        val report = HandTrackingDiagnostician.diagnose(input(interval = 140L))
        assertTrue(report.verdict.startsWith("Автоэкономия"))
    }
}
